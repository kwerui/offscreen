const MAX_REFERENCES = 20;
const MAX_PATH_CHARACTERS = 512;
const MAX_LABEL_CHARACTERS = 240;
const MAX_LINE_NUMBER = 100_000;

const CONTEXTUAL_PATH_PATTERN = /\b(?:that file|this file|that one|the one|it|the file with that failure|the file you just mentioned|(?:first|second|third|fourth|fifth|\d+(?:st|nd|rd|th)?)\s+(?:one|result|file))\b/i;
const CONTEXTUAL_SEARCH_PATTERN = /\b(?:that function|that text|that query|it)\b/i;
const INDEXED_REFERENCE_PATTERN = /\b(?:the )?(first|second|third|fourth|fifth|\d+(?:st|nd|rd|th)?)\s+(?:one|result|file)\b/i;
const INDEXES = new Map([
  ["first", 0], ["second", 1], ["third", 2], ["fourth", 3], ["fifth", 4],
]);

function isSafeProjectPath(path) {
  if (typeof path !== "string" || path.length === 0 || path.length > MAX_PATH_CHARACTERS) {
    return false;
  }

  const normalized = path.replaceAll("\\", "/");
  const parts = normalized.split("/");

  return !normalized.startsWith("/") &&
    !/^[a-z]:/i.test(normalized) &&
    !normalized.includes("\0") &&
    !parts.some((part) => part === "" || part === "." || part === "..") &&
    !parts.some((part) => part === ".git" || part === "node_modules") &&
    !parts.at(-1).startsWith(".env") &&
    !["credentials.json", "token.json", "offscreen.zip", ".npmrc", ".netrc", ".pypirc"].includes(parts.at(-1)) &&
    !/\.(?:pem|key|p12|pfx|crt|cer|der)$/i.test(parts.at(-1)) &&
    !/(?:secret|credential|token|password|private)[._-]?(?:key|keys)?/i.test(parts.at(-1)) &&
    !/(?:^|[._-])(?:api|access|secret|private)?[._-]?keys?(?:$|[._-])/i.test(parts.at(-1));
}

function normalizeLine(line) {
  return Number.isInteger(line) && line >= 1 && line <= MAX_LINE_NUMBER
    ? line
    : undefined;
}

function parseFailureLocation(location) {
  if (typeof location !== "string") {
    return null;
  }

  const match = /^(.*?)(?::(\d+)(?::\d+)?)?$/.exec(location);
  const path = match?.[1];
  const line = match?.[2] ? Number(match[2]) : undefined;

  return isSafeProjectPath(path) ? { path, line: normalizeLine(line) } : null;
}

function getReferenceIndex(text) {
  const match = INDEXED_REFERENCE_PATTERN.exec(text ?? "");
  if (!match) {
    return null;
  }

  return INDEXES.get(match[1].toLowerCase()) ?? Number.parseInt(match[1], 10) - 1;
}

function isContextualPathRequest(text, suppliedPath) {
  return CONTEXTUAL_PATH_PATTERN.test(text ?? "") || CONTEXTUAL_PATH_PATTERN.test(suppliedPath ?? "");
}

export function createProjectReferenceContext() {
  let groups = [];

  function registerGroup(references, source, searchQuery) {
    const safeReferences = references
      .filter((reference) => isSafeProjectPath(reference.path))
      .map((reference) => ({
        path: reference.path.replaceAll("\\", "/"),
        line: normalizeLine(reference.line),
        label: typeof reference.label === "string"
          ? reference.label.slice(0, MAX_LABEL_CHARACTERS)
          : undefined,
      }));

    if (safeReferences.length === 0) {
      return;
    }

    groups.unshift({ references: safeReferences, source, searchQuery });
    groups = groups.slice(0, MAX_REFERENCES);
  }

  function registerResult(toolName, result) {
    if (!result?.success) {
      return;
    }

    if (toolName === "search_project") {
      // Search ordinals are deliberately file-oriented. Only the code-made
      // presentation list is eligible: hidden matches and first-match lines
      // must never affect either ordinal positions or a file open.
      const searchFiles = Array.isArray(result.presentation?.files)
        ? result.presentation.files.map((file) => ({ path: file?.path }))
        : Array.isArray(result.files) && result.files.length > 0
          ? result.files.map((file) => ({ path: file?.path }))
        : result.matches ?? [];

      registerGroup(
        searchFiles.map((match) => ({
          path: match?.path,
          line: undefined,
          label: undefined,
        })),
        "search",
        typeof result.query === "string" ? result.query.slice(0, 200) : undefined
      );
    } else if (["read_project_file", "open_project_file"].includes(toolName)) {
      registerGroup([{ path: result.path, line: result.line ?? result.startLine }], toolName);
    } else if (toolName === "get_git_status") {
      registerGroup(
        ["staged", "unstaged", "untracked"].flatMap((key) => result[key] ?? [])
          .map((entry) => ({ path: entry?.path })),
        "git_status"
      );
    } else if (toolName === "run_project_tests") {
      registerGroup(
        (result.failures ?? []).map((failure) => parseFailureLocation(failure?.file)).filter(Boolean),
        "test_failure"
      );
    }
  }

  function resolve({ toolName, arguments: suppliedArguments = {}, userText }) {
    if (toolName === "search_project") {
      const query = suppliedArguments.query;
      if (!CONTEXTUAL_SEARCH_PATTERN.test(userText ?? "") && !CONTEXTUAL_SEARCH_PATTERN.test(query ?? "")) {
        return { success: true, arguments: suppliedArguments };
      }

      const group = groups.find((candidate) => candidate.source === "search" && candidate.searchQuery);
      return group
        ? { success: true, arguments: { ...suppliedArguments, query: group.searchQuery } }
        : { success: false, error: "I need the function or text to search for." };
    }

    if (!["read_project_file", "open_project_file"].includes(toolName)) {
      return { success: true, arguments: suppliedArguments };
    }

    const suppliedPath = suppliedArguments.path;
    if (!isContextualPathRequest(userText, suppliedPath)) {
      return { success: true, arguments: suppliedArguments };
    }

    const group = groups[0];
    const index = getReferenceIndex(userText) ?? getReferenceIndex(suppliedPath);
    const uniqueReferences = group
      ? [...new Map(group.references.map((reference) => [reference.path, reference])).values()]
      : [];
    const reference = index === null
      ? uniqueReferences.length === 1 ? uniqueReferences[0] : null
      : uniqueReferences[index];

    if (!reference) {
      const options = uniqueReferences.slice(0, 3).map((item) => item.path);
      return {
        success: false,
        error: options.length > 1
          ? `Please choose one: ${options.join(", ")}.`
          : "I need a project file name or a recent result to use.",
      };
    }

    const lineMatch = /\bline\s+(\d+)\b/i.exec(userText ?? "");
    // A search-derived file selection must not inherit a search match line or
    // model-supplied line. Other reference sources (such as a test failure)
    // retain their source-specific line behavior. Explicit speech always wins.
    const line = normalizeLine(lineMatch
      ? Number(lineMatch[1])
      : group?.source === "search" ? undefined : suppliedArguments.line ?? reference.line);
    const argumentsWithPath = { ...suppliedArguments, path: reference.path };

    if (group?.source === "search") {
      delete argumentsWithPath.line;
    }

    if (toolName === "open_project_file" && line !== undefined) {
      argumentsWithPath.line = line;
    }

    return { success: true, arguments: argumentsWithPath };
  }

  return {
    clear: () => { groups = []; },
    registerResult,
    resolve,
    get size() { return groups.length; },
  };
}
