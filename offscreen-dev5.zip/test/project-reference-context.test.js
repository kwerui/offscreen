import assert from "node:assert/strict";
import test from "node:test";
import { createProjectReferenceContext } from "../public/project-reference-context.js";

test("uses exactly the presented distinct-file order for first, second, and third references", () => {
  const context = createProjectReferenceContext();
  context.registerResult("search_project", { success: true, query: "runProjectTests", files: [
    { path: "project-tests.js", firstLine: 271 },
    { path: "public/app.js", firstLine: 37 },
    { path: "public/project-tests-tool.js", firstLine: 1 },
    { path: "server.js", firstLine: 40 },
  ], presentation: { files: [
    { position: 1, path: "project-tests.js" },
    { position: 2, path: "public/project-tests-tool.js" },
    { position: 3, path: "server.js" },
  ] } });

  for (const [ordinal, path] of [["first", "project-tests.js"], ["second", "public/project-tests-tool.js"], ["third", "server.js"]]) {
    assert.deepEqual(context.resolve({ toolName: "open_project_file", arguments: { path: `${ordinal} one` }, userText: `Open the ${ordinal} one.` }), {
      success: true, arguments: { path },
    });
  }
  assert.equal(context.resolve({ toolName: "open_project_file", arguments: { path: "fourth one" }, userText: "Open the fourth one." }).success, false);
});

test("uses an explicit spoken line with a contextual file but never a match line", () => {
  const context = createProjectReferenceContext();
  context.registerResult("search_project", { success: true, query: "tool", presentation: { files: [
    { position: 1, path: "public/project-tests-tool.js" },
  ] } });

  assert.deepEqual(context.resolve({
    toolName: "open_project_file",
    arguments: { path: "that file", line: 1 },
    userText: "Open that file.",
  }).arguments, { path: "public/project-tests-tool.js" });
  assert.deepEqual(context.resolve({
    toolName: "open_project_file",
    arguments: { path: "that file" },
    userText: "Open it at line 120.",
  }).arguments, { path: "public/project-tests-tool.js", line: 120 });
});

test("resolves a unique reference but does not guess an ambiguous one", () => {
  const context = createProjectReferenceContext();
  context.registerResult("read_project_file", { success: true, path: "public/app.js", startLine: 1 });
  assert.deepEqual(context.resolve({ toolName: "read_project_file", arguments: { path: "that file" }, userText: "Read that file." }), {
    success: true, arguments: { path: "public/app.js" },
  });

  context.registerResult("search_project", { success: true, query: "thing", matches: [{ path: "a.js" }, { path: "b.js" }] });
  assert.equal(context.resolve({ toolName: "open_project_file", arguments: { path: "that file" }, userText: "Open that file." }).success, false);
});

test("registers Git and test-failure locations while rejecting unsafe paths", () => {
  const context = createProjectReferenceContext();
  context.registerResult("get_git_status", { success: true, staged: [{ path: ".env" }, { path: "private.key" }], unstaged: [{ path: "server.js" }], untracked: [] });
  assert.deepEqual(context.resolve({ toolName: "open_project_file", arguments: { path: "that file" }, userText: "Open that file." }).arguments, { path: "server.js" });

  context.clear();
  context.registerResult("run_project_tests", { success: true, failures: [{ file: "test/app.test.js:12:3" }, { file: "/etc/passwd:1:1" }] });
  assert.deepEqual(context.resolve({ toolName: "open_project_file", arguments: { path: "the file with that failure" }, userText: "Open the file with that failure." }).arguments, { path: "test/app.test.js", line: 12 });
});

test("uses a prior safe search query, bounds storage, and clears on reset", () => {
  const context = createProjectReferenceContext();
  for (let index = 0; index < 25; index++) {
    context.registerResult("search_project", { success: true, query: `needle${index}`, matches: [{ path: `file${index}.js` }] });
  }
  assert.equal(context.size, 20);
  assert.deepEqual(context.resolve({ toolName: "search_project", arguments: { query: "that function" }, userText: "Search for that function." }).arguments, { query: "needle24" });
  context.clear();
  assert.equal(context.resolve({ toolName: "open_project_file", arguments: { path: "it" }, userText: "Open it." }).success, false);
});
