import assert from "node:assert/strict";
import test from "node:test";

class FakeWebSocket {
  static CONNECTING = 0;
  static OPEN = 1;
  static instances = [];
  constructor() { this.readyState = FakeWebSocket.CONNECTING; this.sentMessages = []; FakeWebSocket.instances.push(this); }
  open() { this.readyState = FakeWebSocket.OPEN; this.onopen?.(); }
  receive(event) { this.onmessage?.({ data: JSON.stringify(event) }); }
  send(message) { this.sentMessages.push(JSON.parse(message)); }
}

function createElement() {
  return {
    addEventListener(type, listener) { this.listeners ??= {}; this.listeners[type] = listener; },
    appendChild(child) { child.parentNode = this; this.children ??= []; this.children.push(child); return child; },
    children: [], classList: { remove() {} }, disabled: false, hidden: true, parentNode: null,
    remove() {}, scrollHeight: 0, scrollTop: 0, textContent: "", value: "",
  };
}

async function flushPromises() { await new Promise((resolve) => setImmediate(resolve)); }

test("routes contextual and explicit project-file opens through the same validated route", async () => {
  const originals = {
    fetch: globalThis.fetch, WebSocket: globalThis.WebSocket, document: globalThis.document,
    window: globalThis.window, navigator: Object.getOwnPropertyDescriptor(globalThis, "navigator"),
    AudioWorkletNode: globalThis.AudioWorkletNode, capabilities: globalThis.__OFFSCREEN_CAPABILITIES__,
  };
  const requests = [];

  try {
    const elements = new Map();
    for (const id of ["connect", "disconnect", "voice-wake", "resume-listening", "clear", "voice", "prompt", "greeting", "transcript", "empty", "status-dot", "status-text", "hosted-demo-notice"]) elements.set(id, createElement());
    elements.get("empty").parentNode = elements.get("transcript");
    globalThis.document = { createElement, getElementById: (id) => elements.get(id) };
    globalThis.window = { AudioContext: class { constructor() { this.audioWorklet = { addModule: async () => {} }; this.currentTime = 0; } close() {} createMediaStreamSource() { return { connect() {}, disconnect() {} }; } } };
    globalThis.AudioWorkletNode = class { constructor() { this.port = {}; } disconnect() {} };
    Object.defineProperty(globalThis, "navigator", { configurable: true, value: { mediaDevices: { getUserMedia: async () => ({ getTracks: () => [] }) } } });
    globalThis.WebSocket = FakeWebSocket;
    globalThis.__OFFSCREEN_CAPABILITIES__ = { isHostedDemo: false, calendar: true, codex: true, developerWorkspace: true, browserControl: true };
    globalThis.fetch = async (url, options) => {
      if (url === "/api/voice-token") return { ok: true, json: async () => ({ token: "test-token" }) };
      requests.push({ url, body: JSON.parse(options.body) });
      if (url === "/api/developer/search") return { ok: true, json: async () => ({ success: true, query: "run project tests", files: [
        { path: "public/app.js", firstLine: 20 },
        { path: "public/project-tests-tool.js", firstLine: 1 },
        { path: "public/tools.js", firstLine: 1 },
        { path: "test/app-project-reference-context.test.js", firstLine: 57 },
      ], presentation: { files: [
        { position: 1, path: "public/app.js" },
        { position: 2, path: "public/project-tests-tool.js" },
        { position: 3, path: "test/app-project-reference-context.test.js" },
      ] } }) };
      if (url === "/api/developer/open-file") return { ok: true, json: async () => ({
        success: true,
        path: JSON.parse(options.body).path,
        ...(JSON.parse(options.body).line === undefined ? {} : { line: JSON.parse(options.body).line }),
      }) };
      throw new Error(`Unexpected request: ${url}`);
    };

    await import(`../public/app.js?project-reference-test=${Date.now()}`);
    await elements.get("connect").listeners.click();
    const socket = FakeWebSocket.instances.at(-1);
    socket.open();
    socket.receive({ type: "session.ready", session_id: "project-reference" });
    socket.receive({ type: "transcript.user", text: "Search the project for run project tests." });
    socket.receive({ type: "tool.call", name: "search_project", call_id: "search", arguments: { query: "run project tests" } });
    socket.receive({ type: "reply.done", status: "completed" });
    await flushPromises();
    socket.receive({ type: "transcript.user", text: "Open the fourth one." });
    socket.receive({ type: "tool.call", name: "open_project_file", call_id: "out-of-range", arguments: { path: "fourth one" } });
    socket.receive({ type: "reply.done", status: "completed" });
    await flushPromises();
    assert.deepEqual(requests, [
      { url: "/api/developer/search", body: { query: "run project tests" } },
    ]);
    socket.receive({ type: "transcript.user", text: "Open the second one." });
    socket.receive({ type: "tool.call", name: "open_project_file", call_id: "contextual-open", arguments: { path: "second one", line: 1 } });
    socket.receive({ type: "reply.done", status: "completed" });
    await flushPromises();
    socket.receive({ type: "transcript.user", text: "Open it at line 120." });
    socket.receive({ type: "tool.call", name: "open_project_file", call_id: "explicit-open", arguments: { path: "that file" } });
    socket.receive({ type: "reply.done", status: "completed" });
    await flushPromises();

    assert.deepEqual(requests, [
      { url: "/api/developer/search", body: { query: "run project tests" } },
      { url: "/api/developer/open-file", body: { path: "public/project-tests-tool.js" } },
      { url: "/api/developer/open-file", body: { path: "public/project-tests-tool.js", line: 120 } },
    ]);
  } finally {
    globalThis.fetch = originals.fetch; globalThis.WebSocket = originals.WebSocket;
    globalThis.document = originals.document; globalThis.window = originals.window;
    Object.defineProperty(globalThis, "navigator", originals.navigator);
    globalThis.AudioWorkletNode = originals.AudioWorkletNode;
    globalThis.__OFFSCREEN_CAPABILITIES__ = originals.capabilities;
  }
});
